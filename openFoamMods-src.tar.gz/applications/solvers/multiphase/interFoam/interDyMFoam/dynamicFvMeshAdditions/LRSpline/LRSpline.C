/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2009 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

\*---------------------------------------------------------------------------*/

// nrs
//
// LRSpline uses cubic spline interpolation from Numerical Recipes in C 2nd Edition
//
#include "LRSpline.H"
// srn
#include "addToRunTimeSelectionTable.H"
#include "Tuple2.H"
#include "IFstream.H"
// nrs
//#include "interpolateSplineXY.H"
// srn
#include "mathematicalConstants.H"
// nrs
#include  "interpolateSplineXY_nrs.H"
// srn

using namespace Foam::constant::mathematical;

// * * * * * * * * * * * * * * Static Data Members * * * * * * * * * * * * * //

namespace Foam
{
namespace solidBodyMotionFunctions
{
    defineTypeNameAndDebug(LRSpline, 0);
    addToRunTimeSelectionTable(solidBodyMotionFunction, LRSpline, dictionary);
};
};


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::solidBodyMotionFunctions::LRSpline::LRSpline
(
    const dictionary& SBMFCoeffs,
    const Time& runTime
)
:
    solidBodyMotionFunction(SBMFCoeffs, runTime)
{
    read(SBMFCoeffs);
}


// * * * * * * * * * * * * * * * * Destructors * * * * * * * * * * * * * * * //

Foam::solidBodyMotionFunctions::LRSpline::~LRSpline()
{}


// * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * * //

Foam::septernion Foam::solidBodyMotionFunctions::LRSpline::transformation() const
{
    scalar t = time_.value();

    if (t < times_[0])
    {
        FatalErrorIn
        (
            "solidBodyMotionFunctions::LRSpline::transformation()"
        )   << "current time (" << t
            << ") is less than the minimum in the data table ("
            << times_[0] << ')'
            << exit(FatalError);
    }

    if (t > times_[times_.size()-1])
    {
        FatalErrorIn
        (
            "solidBodyMotionFunctions::LRSpline::transformation()"
        )   << "current time (" << t
            << ") is greater than the maximum in the data table ("
            << times_[times_.size()-1] << ')'
            << exit(FatalError);
    }

   //nrs
    translationRotationVectors TRV = interpolateSplineXY_nrs
  (
       t,
       times_,
       values_,
       derivs_
   );
    
//    translationRotationVectors TRV = interpolateSplineXY
//    (
//        t,
//        times_,
//        values_
//    );
    // srn

    Info<< "solidBodyMotionFunctions::LRSpline::transformation(): "
        << "Time = " <<  t << " transformation: " << TRV << endl;

    // Convert the rotational motion from deg to rad
    TRV[1] *= pi/180.0;

    quaternion R(TRV[1].x(), TRV[1].y(), TRV[1].z());
    septernion TR(septernion(CofG_ + TRV[0])*R*septernion(-CofG_));

    //Info<< "solidBodyMotionFunctions::LRSpline::transformation(): "
    //    << "Time = " <<  t << " transformation: " << TR << endl;

    return TR;
}


bool Foam::solidBodyMotionFunctions::LRSpline::read(const dictionary& SBMFCoeffs)
{
    solidBodyMotionFunction::read(SBMFCoeffs);

    // If the timeDataFileName has changed read the file

    fileName newTimeDataFileName(SBMFCoeffs_.lookup("timeDataFileName"));

    if (newTimeDataFileName != timeDataFileName_)
    {
        timeDataFileName_ = newTimeDataFileName;

        IFstream dataStream(timeDataFileName_);

        if (dataStream.good())
        {
            List<Tuple2<scalar, translationRotationVectors> > timeValues
            (
                dataStream
            );

            times_.setSize(timeValues.size());
            values_.setSize(timeValues.size());

            forAll(timeValues, i)
            {
                times_[i] = timeValues[i].first();
                values_[i] =timeValues[i].second();
            }
	    
	    Info << "Calculating 2nd Derivs for motions " << endl;
	    // nrs
	    // calculate the 2nd derivatives for all the data - called here so that its only done once
	    derivs_.setSize(timeValues.size());
	    Info << " setSize for derivs, size: " << timeValues.size() << endl;
	    int RetVal = Spline2ndDeriv
		(
			times_,
			values_,
			derivs_
		);
	    if (RetVal == 0)
		    Info << " 2nd Derivs calculated for motions " << endl;
	    else 
		    Info << " Failed to calculate 2nd Derivs for motions " << endl;
	    
	    bool bOutputMotions = false;
	    
	    if (bOutputMotions)
	    {
		    Info << "Num" << " , " << "Time" << " , " << "X_trans" << " , " << "Y_trans" << " , " << "Z_trans" << 
			" , " << "X_trans2ndD" << " , " << "Y_trans2ndD" << " , " << "Z_trans2ndD" << endl;
	    
		    for (int i = 0; i < timeValues.size(); i++)
		    {
			    Info << i << " , " << times_[i] << 
				" , " << values_[i][0].component(vector::X)  <<
				" , " << values_[i][0].component(vector::Y) << 
				" , " << values_[i][0].component(vector::Z) << 
				" , " << derivs_[i][0].component(vector::X)  <<
				" , " << derivs_[i][0].component(vector::Y) << 
				" , " << derivs_[i][0].component(vector::Z) << 
				endl;
		    }
	    }

	    // srn
        }
        else
        {
            FatalErrorIn
            (
                "solidBodyMotionFunctions::LRSpline::read(const dictionary&)"
            )   << "Cannot open time data file " << timeDataFileName_
                << exit(FatalError);
        }
    }

    SBMFCoeffs_.lookup("CofG") >> CofG_;

    return true;
}


// ************************************************************************* //
