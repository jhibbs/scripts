/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2010-2010 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

\*---------------------------------------------------------------------------*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
//    Spline interpolation function written by Lloyd's Register              //
//    as an alternative to SKASpline.                                                     //
//                                                                                                         //
//     Author: Neil Southall (nrs)                                                          //
//     Date: May 2011                                                                           //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

#include "interpolateSplineXY_nrs.H"
#include "primitiveFields.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

template<class Type>
Foam::Field<Type> Foam::interpolateSplineXY_nrs
(
    const scalarField& xNew,
    const scalarField& xOld,
    const Field<Type>& yOld,
    const Field<Type>& y2a
)
{
    Field<Type> yNew(xNew.size());
    
     forAll(xNew, i)
    {
	yNew[i] = interpolateSplineXY_nrs(xNew[i], xOld, yOld, y2a);
    }

   return yNew;
}


template<class Type>
Type Foam::interpolateSplineXY_nrs
(
    const scalar x,
    const scalarField& xOld,
    const Field<Type>& yOld,
    const Field<Type>& y2a
)
{
     label n = xOld.size();

    // early exit if out of bounds or only one value
    if (n == 1 || x < xOld[0])
    {
        return yOld[0];
    }
    if (x > xOld[n - 1])
    {
        return yOld[n - 1];
    }

    // linear interpolation if only two values
    if (n == 2)
    {
        return (x - xOld[0])/(xOld[1] - xOld[0])*(yOld[1] - yOld[0]) + yOld[0];
    }

    // find bounding knots
    label hi = 0;
    while (hi < n && xOld[hi] < x)
    {
        hi++;
    }

    label lo = hi - 1;

    const Type& y1 = yOld[lo];
    const Type& y2 = yOld[hi];
   
    Type y0;
    if (lo == 0)
    {
        y0 = 2*y1 - y2;
    }
    else
    {
        y0 = yOld[lo - 1];
    }

    Type y3;
    if (hi + 1 == n)
    {
        y3 = 2*y2 - y1;
    }
    else
    {
        y3 = yOld[hi + 1];
    }

	// nrs
	// Taken from Numerical Recipies in C, 2nd Edition
	// xOld == xa
	// yOld == ya
	// y2a is 2nd derivative of y from function Spline2ndDeriv_nrs
	// 
	scalar h = xOld[hi] - xOld[lo];
	scalar a = (xOld[hi] - x) / h;
	scalar b = (x - xOld[lo]) / h;

	// evaluate the cubic spline
	return a * yOld[lo] + b * yOld[hi] + 
		((a*a*a - a) * y2a[lo] + 
		(b*b*b - b) * y2a[hi]) *
		(h*h) / 6.0;
	// srn
}

template<class Type>
int Foam::Spline2ndDeriv
(
    const scalarField& xOld,
    const Field<Type>& yOld,
    Field<Type>& y2a
)
{
	Info << " in Spline2ndDeriv " << endl;
	scalarField tmp_yOld(yOld.size());
	scalarField tmp_y2a;//(yOld.size());
	//double* tmp_yOld = new double[yOld.size()];
	//double* tmp_y2a = new double[yOld.size()];
	// find the 2nd derivatives for the spline for all 6 components

	for (int i = 0; i < 2; i++)
	{
		// doing this separately for each component is a little messy
		// but not all operations are available for Field	and this method 
		// minimises the number of changes required to the source
		for (int j = 0; j < yOld.size(); j++)
			tmp_yOld[j] = yOld[j][i].component(vector::X);
		//Spline2ndDeriv_scalarField(xOld, tmp_yOld, tmp_y2a);
		tmp_y2a = Spline2ndDeriv_scalarField(xOld, tmp_yOld);
		for (int j = 0; j < yOld.size(); j++)
			y2a[j][i].replace(vector::X, tmp_y2a[j]);
		Info << "After X component " << endl;
	    
		for (int j = 0; j < yOld.size(); j++)
			tmp_yOld[j] = yOld[j][i].component(vector::Y);
		//Spline2ndDeriv_scalarField(xOld, tmp_yOld, tmp_y2a);
		tmp_y2a = Spline2ndDeriv_scalarField(xOld, tmp_yOld);
		for (int j = 0; j < yOld.size(); j++)
			y2a[j][i].replace(vector::Y, tmp_y2a[j]);
		Info << "After Y component " << endl;
	    
		for (int j = 0; j < yOld.size(); j++)
			tmp_yOld[j] = yOld[j][i].component(vector::Z);
		//Spline2ndDeriv_scalarField(xOld, tmp_yOld, tmp_y2a);
		tmp_y2a = Spline2ndDeriv_scalarField(xOld, tmp_yOld);
		for (int j = 0; j < yOld.size(); j++)
			y2a[j][i].replace(vector::Z, tmp_y2a[j]);
		Info << "After Z component " << endl;
	    
	}
	return 0;
}

//int Foam::Spline2ndDeriv_scalarField
//(
//    const scalarField& xOld,
//    const scalarField& yOld,
//   scalarField& y2a
//)
Foam::scalarField& Foam::Spline2ndDeriv_scalarField
(
    const scalarField& xOld,
    const scalarField& yOld
)
{
	scalarField y2a(yOld.size());
	Info << " in Spline2ndDeriv_scalarField " << endl;
	// nrs
	// numerical recipes code is 1-based - swapped to 0-based here
	
	int n = yOld.size();
	
	scalarField u;
	u.setSize(n);
	//double* u = new double[n];
	Info << " setSize for u to: " << n << endl;
	
	y2a[0] = 0.0; // use natural splines - 2nd derivative set to 0 at the ends
	u[0] = 0.0;
	u[n - 1] = 0.0;
		
	for (int i = 1; i < n - 1; i++)
	{
		scalar sig = (xOld[i] - xOld[i - 1]) / (xOld[i + 1] - xOld[i - 1]);
		scalar p = sig*y2a[i-1] + 2.0;
		y2a[i] = (sig - 1.0) / p;
				
		//u[i] = (yOld[i + 1] - yOld[i])/(xOld[i + 1] - xOld[i]) - 
		//			(yOld[i] - yOld[i - 1])/(xOld[i] - xOld[i - 1]);
		scalar u_temp = (yOld[i + 1] - yOld[i])/(xOld[i + 1] - xOld[i]) - 
					(yOld[i] - yOld[i - 1])/(xOld[i] - xOld[i - 1]);
		
		//u[i] = (6.0 * u[i] / (xOld[i + 1] - xOld[i - 1]) - sig * u[i-1]) / p;
		u[i] = (6.0 * u_temp / (xOld[i + 1] - xOld[i - 1]) - sig * u[i-1]) / p;
		
		//Info << i << " , " <<  xOld[i] << " , " << u[i]  << " sig: " << sig << " p : " << p << endl;
	}

	scalar qn = 0.0;
	scalar un = 0.0; // natural spline 2nd derivative for upper end

	y2a[n] = (un - qn * u[n - 1])/(qn*y2a[n - 1] + 1.0);
	Info << endl << " y2a[n]  " << y2a[n]  << endl << endl;
	
	for (int k = n - 2; k >= 0; k--)
	{
		y2a[k] = y2a[k]  * y2a[k+1]+ u[k];
		//Info << k << " , " << xOld[k] << " , " <<y2a[k]  << endl;
	}

	for (int i = 0; i < n; i++)
	{
		Info << " u[" << i << "]: " << u[i] << endl;
	}
	Info << " before delete " << endl;
	//delete[] u;
	Info << " out of Spline2ndDeriv_scalarField " << endl;
	return y2a;
}

