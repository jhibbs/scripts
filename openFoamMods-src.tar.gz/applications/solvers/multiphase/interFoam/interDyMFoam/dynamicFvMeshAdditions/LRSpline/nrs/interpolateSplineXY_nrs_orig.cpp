/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 2010-2010 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

\*---------------------------------------------------------------------------*/

#include "stdafx.h"
#include "interpolateSplineXY.h"
//#include "primitiveFields.H"

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

//template<class Type>
//Foam::Field<Type> Foam::interpolateSplineXY
//(
//    const scalarField& xNew,
//    const scalarField& xOld,
//    const Field<Type>& yOld
//)
//{
//    scalarField yNew(xNew.size());
//
//    forAll(xNew, i)
//    {
//        yNew[i] = interpolateSmoothXY(xNew[i], xOld, yOld);
//    }
//
//    return yNew;
//}


double Foam::interpolateSplineXY
(
    int n,
	const scalar x,
    const scalar* xOld,
    const scalar* yOld
)
{
	//label n = xOld.size();

    // early exit if out of bounds or only one value
    if (n == 1 || x < xOld[0])
    {
        return yOld[0];
    }
    if (x > xOld[n - 1])
    {
        return yOld[n - 1];
    }

    // linear interpolation if only two values
    if (n == 2)
    {
        // nrs
		//return (x - xOld[0])/(xOld[1] - xOld[0])*(yOld[1] - yOld[0]) + yOld[0];
		// additional brackets for enhanced readability
		return ((x - xOld[0])/(xOld[1] - xOld[0]))*(yOld[1] - yOld[0]) + yOld[0];
		// srn
    }

    // find bounding knots
    // nrs
	//label hi = 0;
    label hi = 1;
    // srn
	while (hi < n && xOld[hi] < x)
    {
        hi++;
    }

    label lo = hi - 1;

    const Type& y1 = yOld[lo];
    const Type& y2 = yOld[hi];

    Type y0;
    if (lo == 0)
    {
        y0 = 2*y1 - y2;
    }
    else
    {
        y0 = yOld[lo - 1];
    }

    Type y3;
    if (hi + 1 == n)
    {
        y3 = 2*y2 - y1;
    }
    else
    {
        y3 = yOld[hi + 1];
    }

    // weighting
    scalar mu = (x - xOld[lo])/(xOld[hi] - xOld[lo]);

    // interpolate
    return
        0.5
       *(
            2*y1
          + mu
           *(
               -y0 + y2
              + mu*((2*y0 - 5*y1 + 4*y2 - y3) + mu*(-y0 + 3*y1 - 3*y2 + y3))
            )
        );
}

double Foam::interpolateSplineXY_NRS
(
    int n,
	const scalar x,
    const scalar* xOld,
    const scalar* yOld,
	const scalar* y2a
)
{
	//label n = xOld.size();

    // early exit if out of bounds or only one value
    if (n == 1 || x < xOld[0])
    {
        return yOld[0];
    }
    if (x > xOld[n - 1])
    {
        return yOld[n - 1];
    }

    // linear interpolation if only two values
    if (n == 2)
    {
        // nrs
		//return (x - xOld[0])/(xOld[1] - xOld[0])*(yOld[1] - yOld[0]) + yOld[0];
		// additional brackets for enhanced readability
		return ((x - xOld[0])/(xOld[1] - xOld[0]))*(yOld[1] - yOld[0]) + yOld[0];
		// srn
    }

    // find bounding knots
    // nrs
	//label hi = 0;
    label hi = 1;
    // srn
	
	// nrs - this is a very slow routine to find the high and low knots - use bisection instead?
	while (hi < n && xOld[hi] < x)
    {
        hi++;
    }

    label lo = hi - 1;

    const Type& y1 = yOld[lo];
    const Type& y2 = yOld[hi];

    Type y0;
    if (lo == 0)
    {
        y0 = 2*y1 - y2;
    }
    else
    {
        y0 = yOld[lo - 1];
    }

    Type y3;
    if (hi + 1 == n)
    {
        y3 = 2*y2 - y1;
    }
    else
    {
        y3 = yOld[hi + 1];
    }

    // weighting
    //scalar mu = (x - xOld[lo])/(xOld[hi] - xOld[lo]);

    //// interpolate
    //return
    //    0.5
    //   *(
    //        2*y1
    //      + mu
    //       *(
    //           -y0 + y2
    //          + mu*((2*y0 - 5*y1 + 4*y2 - y3) + mu*(-y0 + 3*y1 - 3*y2 + y3))
    //        )
    //    );

	// nrs
	// Taken from Numerical Recipies in C, 2nd Edition
	// xOld == xa
	// yOld == ya
	// y2a is 2nd derivative of y from function Spline2ndDeriv_NRS
	// 
	scalar h = xOld[hi] - xOld[lo];
	scalar a = (xOld[hi] - x) / h;
	scalar b = (x - xOld[lo]) / h;

	// evaluate the cubic spline
	return a * yOld[lo] + b * yOld[hi] + 
		((a*a*a - a) * y2a[lo] + 
		(b*b*b - b) * y2a[hi]) *
		(h*h) / 6.0;
	// srn
}

int Foam::Spline2ndDeriv_NRS
(
  const scalarField& xOld,
    const Field<Type>& yOld,
    const Field<Type>& y2a
)
{
	// nrs
	// numerical recipes code is 1-based - swapped to 0-based here
	Type* u = new Type[n];

	y2[0] = 0.0; // use natural splines - 2nd derivative set to 0 at the ends
	u[0] = 0.0;
	
	for (int i = 1; i < n - 1; i++)
	{
		Type sig = (xOld[i] - xOld[i - 1]) / (xOld[i + 1] - xOld[i - 1]);
		Type p = sig*y2[i-1] + 2.0;
		y2[i] = (sig - 1.0) / p;
		u[i] = (yOld[i + 1] - yOld[i])/(xOld[i + 1] - xOld[i]) - 
					(yOld[i] - yOld[i - 1])/(xOld[i] - xOld[i - 1]);
		u[i] = (6.0 * u[i] / (xOld[i + 1] - xOld[i - 1]) - sig * u[i-1]) / p;
		
	}

	scalar qn = 0.0;
	scalar un = 0.0; // natural spline 2nd derivative for upper end

	y2[n] = (un - qn * u[n - 1])/(qn*y2[n - 1] + 1.0);
	for (int k = n - 2; k >= 0; k--)
		y2[k] = y2[k] * y2[k+1] + u[k];

	delete u;
	return 0;
}

// ************************************************************************* //


