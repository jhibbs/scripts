/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2009 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    selects internal faces interior to the domain and a polygon

\*---------------------------------------------------------------------------*/

#include "argList.H"
#include "Time.H"
#include "fvMesh.H"
#include "faceSet.H"

using namespace Foam;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

// Main program:

int main(int argc, char *argv[])
{
	argList::validArgs.append("setName");
#   include "setRootCase.H"
    word setName(args.args()[1]);
#   include "createTime.H"
    runTime.functionObjects().off();
#   include "createMesh.H"

/*
	scalar xmin, xmax, ymin, ymax, zmin, zmax, xcen, ycen, zcen;
	xmin =  1.0e10;
	ymin =  1.0e10;
	zmin =  1.0e10;
	xmax = -1.0e10;
	ymax = -1.0e10;
	zmax = -1.0e10;
*/
	// read the polygon for selection of faces

	IOdictionary bafflesDict
	(
		IOobject
		(
			"bafflesDict",
			runTime.system(),
			mesh,
			IOobject::MUST_READ,
			IOobject::NO_WRITE
		)
	);

	List<List<vector> > Xp(bafflesDict.lookup("polygons"));
	int npols = Xp.size();

	faceSet fSet(mesh, setName, 100);

	// Get face centres and normal
    const pointField& fc = mesh.faceCentres();
    vectorField n = mesh.faceAreas();
    n /= mag(n);

    Info << "Found " << fc.size() << " faces" << endl;
	Info << "Found " << npols << " baffles" << endl;
/*
    forAll(fc, faceI)
    {
		if (fc[faceI].x() > xmax) xmax = fc[faceI].x();
		if (fc[faceI].y() > ymax) ymax = fc[faceI].y();
		if (fc[faceI].z() > zmax) zmax = fc[faceI].z();

		if (fc[faceI].x() < xmin) xmin = fc[faceI].x();
		if (fc[faceI].y() < ymin) ymin = fc[faceI].y();
		if (fc[faceI].z() < zmin) zmin = fc[faceI].z();
    }

	xcen = 0.5*(xmin + xmax);
    ycen = 0.5*(ymin + ymax);
    zcen = 0.5*(zmin + zmax);

    Info << " Center of the domain " << xcen << "   " << ycen << "   " << zcen << endl;
  */

    forAll(fc, faceI)
    {
		// is it inside the polygon?
		scalar x,z,y;
		x = fc[faceI].x();
		y = fc[faceI].y();
		z = fc[faceI].z();
		int ipol;

		for (ipol = 0; ipol < npols; ipol++)
		{
			int npol = Xp[ipol].size();
			int i, j, c = 0;

			for (i = 0, j = npol-1; i < npol; j = i++)
			{
			 	if ((((Xp[ipol][i].y() <= y) && (y < Xp[ipol][j].y())) ||
					((Xp[ipol][j].y() <= y) && (y < Xp[ipol][i].y()))) &&
					(x < (Xp[ipol][j].x() - Xp[ipol][i].x()) * (y - Xp[ipol][i].y()) / (Xp[ipol][j].y() - Xp[ipol][i].y()) + Xp[ipol][i].x()))
				{
					//Info << "****FOUND****" << endl;
					//Info << "Checking " << x << " >= " << x2 << " && " << x << " < " << x1 << endl;

					//Info << " y: " << y << " y2: " << y2 << " y1: " << y1 << endl;
                    c = !c;
				}


			}

			if (c==1)
			{
				if (mesh.isInternalFace(faceI))
				{
					fSet.insert(faceI);
				}
			}
		} // for ipol=
	} // forAll

	Info << "Selected " << returnReduce(fSet.size(), sumOp<label>())
		<< " faces out of " << returnReduce(mesh.nFaces(), sumOp<label>())
		<< nl << endl;

    // Write the updated set
    fSet.write();

	Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //

