/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2009 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software; you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation; either version 2 of the License, or (at your
    option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM; if not, write to the Free Software Foundation,
    Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA

Description
    selects internal faces interior to the domain and a polygon

\*---------------------------------------------------------------------------*/

#include "argList.H"
#include "Time.H"
#include "fvMesh.H"
#include "faceSet.H"

using namespace Foam;

// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

// Main program:

int main(int argc, char *argv[])
{
    argList::validArgs.append("setName");
    argList::validArgs.append("patchName");
#   include "setRootCase.H"
    word setName(args.args()[1]);

    word patchName(args.args()[2]);

#   include "createTime.H"
    runTime.functionObjects().off();
#   include "createMesh.H"

// read the polygon for selection of faces

	IOdictionary faceWallsDict
	(
		IOobject
		(
			setName,
			runTime.system(),
			mesh,
			IOobject::MUST_READ,
			IOobject::NO_WRITE
		)
	);
   
	List<List<vector> > Xp(faceWallsDict.lookup("polygons"));
	int npols = Xp.size();
	faceSet fSet(mesh, setName, 100);

	const polyBoundaryMesh& patches = mesh.boundaryMesh();
	forAll(patches, patchI)
    {
        const polyPatch& pp = patches[patchI];
        Info << pp.name() << endl;
          
		if (pp.name() == patchName)
		{
			const pointField& fc = pp.faceCentres();
			forAll(fc, faceI)
			{
				//   is it inside the polygon?
				scalar x,z,y;
				x = fc[faceI].x();
				y = fc[faceI].y();
				z = fc[faceI].z();
				
				int ipol; 
				for (ipol = 0; ipol < npols; ipol++) 
				{ 
					int npol = Xp[ipol].size();
					int i, j, c = 0;
					
					scalar minX = 1000000, minY = 1000000, maxX = -1000000, maxY = -1000000;
					scalar curX, curY = 0;
					// find smallest x,y and largest x,y
					int itest = 0;
					for (itest = 0; itest < 4; itest++) 
					{
						curX = Xp[ipol][itest].x();
						curY = Xp[ipol][itest].y();
						
						if (curX < minX)
							minX = curX;
						
						if (curY < minY)
							minY = curY;
							
						if (curX > maxX)
							maxX = curX;
						
						if (curY > maxY)
							maxY = curY;
					}
					
					scalar left = minX;
					scalar right = maxX;
					scalar top = maxY;
					scalar bottom = minY;
					
					Info << "x: " << x << " y: " << y << endl;
					Info << "left: " << left << "  right: " << right << "  top: " << top << "  bottom: " << bottom << endl;
					if ((x >= left) && (x < right) && (y <= top) && (y > bottom))
					{
						fSet.insert(pp.start() + faceI);
						Info << "   " << faceI << "   " << fc[faceI] << endl;
					}
						
				}
			}
		}
	}

	Info<< "Selected " << returnReduce(fSet.size(), sumOp<label>())
		<< " faces out of " << returnReduce(mesh.nFaces(), sumOp<label>())
		<< nl << endl;

	// Write the updated set
	fSet.write();
	Info<< "End\n" << endl;

    return 0;
}


// ************************************************************************* //
