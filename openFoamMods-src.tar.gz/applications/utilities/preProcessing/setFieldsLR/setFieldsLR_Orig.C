/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2010 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Description
    Selects a cell set through a dictionary.
    
    // nrs
    setFieldsLR is a custom verison of setFields which calculates alpha1 for 
    partially filled cells cut by the undisturbed free surface.  Not written for the 
    general case (e.g. it assumes that normal to the free surface is the Y axis) 
    // srn

\*---------------------------------------------------------------------------*/
 
#include "argList.H"
#include "timeSelector.H"
#include "Time.H"
#include "fvMesh.H"
#include "topoSetSource.H"
#include "cellSet.H"
#include "volFields.H"
#include "boxToCell.H"
#include "plane.H"

#include "cuttingPlane.H"
#include "triPointRef.H"

using namespace Foam;

template<class GeoField>
void setFieldType
(
    const fvMesh& mesh,
    const labelList& selectedCells,
    const point& ptMax,
    Istream& fieldValueStream
)
{
    word fieldName(fieldValueStream);

    IOobject fieldHeader
    (
        fieldName,
        mesh.time().timeName(),
        mesh,
        IOobject::MUST_READ
    );

    bool bShowInfo = false;

    // Check field exists
    if (fieldHeader.headerOk())
    {
        if (bShowInfo)
        	Info<< "    Setting " << fieldHeader.headerClassName()
            << " " << fieldName << endl;

        GeoField field(fieldHeader, mesh);

        typename GeoField::value_type value
        (
            static_cast<const typename GeoField::value_type&>
            (
                pTraits<typename GeoField::value_type>(fieldValueStream)
            )
        );

        Info << " value: " << value << endl;

        if (selectedCells.size() == field.size())
        {
            field.internalField() = value;
        }
        else
        {
            forAll(selectedCells, celli)
            {
                field[selectedCells[celli]] = value;
            }

            // nrs - Set partial alpha based on cell geometry
            double rY_freesurface = ptMax.y();
            if (bShowInfo)
            	Info << " Y coordinate of undisturbed free surface: " << rY_freesurface << endl;

			// Define cutting plane as undisturbed free surface and find cells that cutting plane intersects
			const plane myFreeSurfacePlane(ptMax, vector(0, 1, 0));
			cuttingPlane myCuttingPlane(myFreeSurfacePlane, mesh, true);
			const labelList& cutCells = myCuttingPlane.cutCells();
			cellSet someCells(mesh, "someCells", cutCells);

			
			if (bShowInfo)
				Info << " Number of cut cells: " << cutCells.size() << endl;

			//const faceList & ff = mesh.faces();
			const pointField & pp = mesh.points();

			// cellSet finds a list of triangular faces so in the list, we will most probably get all our cells listed twice.
			// Store the ID for the last cell we computed and prevent recalculation of the immersed volume;
			int nLastCell = -1;

			forAll(cutCells, celli)
			{
				int nCellID = cutCells[celli];

				if (nCellID != nLastCell)
				{
					nLastCell = nCellID;

					if (bShowInfo)
						Info << endl << endl << " Cell ID: " << nCellID << " Centroid: " << mesh.cellCentres()[nCellID]
											<< " Volume: " << mesh.cellVolumes()[nCellID] << endl << endl << endl;

					const labelList& faces = mesh.cells()[nCellID];
					//const labelListList& pointEdges = mesh.pointEdges();
					// OpenFOAM doesn't seem to support proper lists so we have to stick with
					// lists that have to have their size declared apriori
					const label maxedges = 4;
					edgeList myIntersectingEdges(maxedges); // don't know what max number of sides is
					int nNumIntersectingEdges = 0;

					// find the bottom face (not going to work if bottom face cuts the free surface - Fine for Aquarius
					// as we know that the bottom face will always be horizontal, but won't work for the general case
					face myBottomFace;
					bool bBottomFaceFound = false; // would rather test for myBottomFace == null but it doesn't seem to be supported

					forAll(faces, facei)
					{
						int nFaceID = faces[facei];
						if (bShowInfo)
							Info << " face: " << facei << " ID: " << nFaceID << endl;
						const face& myFace = mesh.faces()[nFaceID];
						if (bShowInfo)
							Info << " face details: " << myFace << endl;
						pointField myFacePoints = myFace.points(pp);

						if (bShowInfo)
							Info << " myFacePoints: " << endl;

						double rMax = Foam::max(myFacePoints & vector(0,1,0));
						double rMin = Foam::min(myFacePoints & vector(0,1,0));

						if (rMax < rY_freesurface)
						{
							if (bShowInfo)
								Info << " rMax of " << rMax << " is below free surface level of " << rY_freesurface << " min is: " << rMin << endl;
							myBottomFace = myFace;
							bBottomFaceFound = true;
						}
						else if (rMin < rY_freesurface && rMax > rY_freesurface)
						{
							// face cuts the free surface.  Find the edges that cut the free surface and store them
							const edgeList& myEdges = myFace.edges();
							forAll(myEdges, edgei)
							{
								if (bShowInfo)
									Info << " Start: " << pp[myEdges[edgei].start()] << " End: " << pp[myEdges[edgei].end()] << endl;
								if ((pp[myEdges[edgei].start()].y() < rY_freesurface && pp[myEdges[edgei].end()].y() > rY_freesurface) ||
										(pp[myEdges[edgei].start()].y() > rY_freesurface && pp[myEdges[edgei].end()].y() < rY_freesurface))
								{
									// check if we already have this edge
									bool bAddEdge = true;
									forAll(myIntersectingEdges, edge2i)
									{
										if (myIntersectingEdges[edge2i] == myEdges[edgei])
											bAddEdge = false;
									}
									if (bAddEdge)
									{
										myIntersectingEdges[nNumIntersectingEdges] = myEdges[edgei];
										nNumIntersectingEdges++;
									}

									if (bShowInfo)
										Info << " myIntersectingEdges1: " << myIntersectingEdges << endl;
								}
							}
						}
					}

					if (bBottomFaceFound)
					{
						if (bShowInfo)
							Info << " Bottom face: " << myBottomFace << endl;
						const pointField& myBottomFacePoints = myBottomFace.points(pp);

						myIntersectingEdges.resize(nNumIntersectingEdges);
						if (bShowInfo)
							Info << " Intersecting edges: " << myIntersectingEdges << endl;
						// intersect the edges with the free surface to find the new points
						// need to do this in the right order based on the points on the bottom face
						pointField myPointsAtFreeSurface(myBottomFacePoints.size());

						forAll(myBottomFacePoints, point2i)
						{
							point nPoint = myBottomFacePoints[point2i];
							if (bShowInfo)
								Info << " Point: " << point2i << " : " << nPoint << endl;
							// find the matching edge
							forAll(myIntersectingEdges, edge2i)
							{
								const edge& myEdge = myIntersectingEdges[edge2i];
								point ptStartVertex = mesh.points()[myEdge.start()];
								point ptEndVertex = mesh.points()[myEdge.end()];

								if ((ptStartVertex == nPoint) || (ptEndVertex == nPoint))
								{
									if (bShowInfo)
										Info << " Matched edge " << endl;
									point ptNewPointOnFreeSurface = ptStartVertex + (ptEndVertex - ptStartVertex) *
											((rY_freesurface - ptStartVertex.y()) / (ptEndVertex.y() - ptStartVertex.y()));
									if (bShowInfo)
										Info << " Made new point on free surface.  StartVertex: " << ptStartVertex <<
											" End vertex: " << ptEndVertex << " New Point: " << ptNewPointOnFreeSurface << endl;
									// Add new point to myPointsAtFreeSurface - can use same indexer as myBottomFacePoints
									myPointsAtFreeSurface[point2i] = ptNewPointOnFreeSurface;
								}
							}
						}

						if (bShowInfo)
							Info << " New points found: " << myPointsAtFreeSurface << endl;

						// find volume of cell below free surface
						const pointField& myPointsAtFS(myPointsAtFreeSurface);
						if (bShowInfo)
						{
							Info << " myBottomFacePoints: " << myBottomFacePoints << endl;
							Info << " myPointsAtFS: " << myPointsAtFS << endl;
						}

						//double rVol = myBottomFace.sweptVol(myPointsAtFS, myBottomFacePoints);
						//if (bShowInfo)
						//	Info << " Vol from sweptVol: " << rVol << endl;

						// for some reason this is not working if I call face.sweptVol directly.
						// Have to do it longhand instead

						double sv = 0.0;

						point centreOldPoint = point::zero;
						label nPoints = myBottomFacePoints.size();
						for (register label pI=0; pI<nPoints; pI++)
						{
							centreOldPoint += myBottomFacePoints[pI];
						}
						centreOldPoint /= nPoints;

						point centreNewPoint = point::zero;
						for (register label pINew=0; pINew<nPoints; pINew++)
						{
							centreNewPoint += myPointsAtFS[pINew];
						}
						centreNewPoint /= nPoints;

						point nextOldPoint = centreOldPoint;
						point nextNewPoint = centreNewPoint;

						register label pI2;
						for (pI2 = 0; pI2 < nPoints; pI2++)
						{
							if (pI2 < nPoints - 1)
							{
								nextOldPoint = myBottomFacePoints[pI2 + 1];
								nextNewPoint = myPointsAtFS[pI2 + 1];
							}
							else
							{
								nextOldPoint = myBottomFacePoints[0];
								nextNewPoint = myPointsAtFS[0];
							}

							// Note: for best accuracy, centre point always comes last
							sv += triPointRef
								  (
									  centreOldPoint,
									  myBottomFacePoints[pI2],
									  nextOldPoint
								  ).sweptVol
								  (
									  triPointRef
									  (
										  centreNewPoint,
										  myPointsAtFS[pI2],
										  nextNewPoint
									  )
								  );
						}

						if (bShowInfo)
							Info << " Cell volume: " << mesh.cellVolumes()[nCellID] << " Volume under free surface: " << sv <<
								" Set Alpha1 to: " << fabs(sv) / mesh.cellVolumes()[nCellID] << endl;

						// set alpha1 to new value
						// value will invariably have been set to 1 in setFields, but this ensures consistency and gets it in the correct format
						// NRS 30/05/2012
						// Sometimes finds negative of volume dut to the way cell vertices are numbered, so 
						// always use the magnitude of sv
						// field[nCellID] = value * sv / mesh.cellVolumes()[nCellID];
						field[nCellID] = value * fabs(sv) / mesh.cellVolumes()[nCellID];
						// SRN 30/05/2012
}
					else
					{
						if (bShowInfo)
							Info << " No bottom face found " << endl;
					}
				}
			}
		}

        forAll(field.boundaryField(), patchi)
        {
            field.boundaryField()[patchi] =
                field.boundaryField()[patchi].patchInternalField();
        }

        field.write();
    }
    else
    {
        WarningIn
        (
            "void setFieldType"
            "(const fvMesh& mesh, const labelList& selectedCells,"
            "Istream& fieldValueStream)"
        ) << "Field " << fieldName << " not found" << endl;
    }
}


class setField
{
public:

    setField()
    {}

    autoPtr<setField> clone() const
    {
        return autoPtr<setField>(new setField());
    }

    point ptRegionMax;
    point ptRegionMin;

    class iNew
    {
        const fvMesh& mesh_;
        const labelList& selectedCells_;
        const point& ptMax_;

    public:

        iNew(const fvMesh& mesh, const labelList& selectedCells, const point& ptMax)
        :
            mesh_(mesh),
            selectedCells_(selectedCells),
            ptMax_(ptMax)
        {}

        autoPtr<setField> operator()(Istream& fieldValues) const
        {
            word fieldType(fieldValues);

            if (fieldType == "volScalarFieldValue")
            {
                setFieldType<volScalarField>
                    (mesh_, selectedCells_, ptMax_, fieldValues);
            }
            else if (fieldType == "volVectorFieldValue")
            {
                setFieldType<volVectorField>
                    (mesh_, selectedCells_, ptMax_, fieldValues);
            }
            else if (fieldType == "volSphericalTensorFieldValue")
            {
                setFieldType<volSphericalTensorField>
                    (mesh_, selectedCells_, ptMax_, fieldValues);
            }
            else if (fieldType == "volSymmTensorFieldValue")
            {
                setFieldType<volSymmTensorField>
                    (mesh_, selectedCells_, ptMax_, fieldValues);
            }
            else if (fieldType == "volTensorFieldValue")
            {
                setFieldType<volTensorField>
                    (mesh_, selectedCells_, ptMax_, fieldValues);
            }
            else
            {
                WarningIn("setField::iNew::operator()(Istream& is)")
                    << "field type " << fieldType << " not currently supported"
                    << endl;
            }

            return autoPtr<setField>(new setField());
        }
    };
};


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    timeSelector::addOptions();

#   include "setRootCase.H"
#   include "createTime.H"

    // Get times list
    instantList timeDirs = timeSelector::select0(runTime, args);

#   include "createMesh.H"

    Info<< "Reading setFieldsDict\n" << endl;

    IOdictionary setFieldsDict
    (
        IOobject
        (
            "setFieldsDict",
            runTime.system(),
            mesh,
            IOobject::MUST_READ,
            IOobject::NO_WRITE
        )
    );

    if (setFieldsDict.found("defaultFieldValues"))
    {
        Info<< "Setting field default values" << endl;
        PtrList<setField> defaultFieldValues
        (
            setFieldsDict.lookup("defaultFieldValues"),
            setField::iNew(mesh, labelList(mesh.nCells()), point(0,0,0))
        );
        Info<< endl;
    }


    Info<< "Setting field region values" << endl;

    PtrList<entry> regions(setFieldsDict.lookup("regions"));

    forAll(regions, regionI)
    {
        const entry& region = regions[regionI];

        autoPtr<topoSetSource> cellSelector =
            topoSetSource::New(region.keyword(), mesh, region.dict());

        cellSet selectedCellSet
        (
            mesh,
            "cellSet",
            mesh.nCells()/10+1  // Reasonable size estimate.
        );

        cellSelector->applyToSet
        (
            topoSetSource::NEW,
            selectedCellSet
        );

        // nrs
        point ptRegionMax, ptRegionMin;

        if (regions.size() == 1) // only do this for conventional setFieldsDict
		{
			const entry& region = regions[0];
			if (region.name() =="::boxToCell")
			{
				//Info << " region end line: " << region.endLineNumber() << endl;
				//Info << " region keyword: " << region.keyword() << endl;
				//Info << " region dict: " << region.dict() << endl;
				//Info << region.dict().lookup("box") << endl;

				treeBoundBox bb;
				bb = region.dict().lookup("box");
				ptRegionMax = bb.max();
				ptRegionMin = bb.min();
			}
		}

        PtrList<setField> fieldValues
        (
            region.dict().lookup("fieldValues"),
            setField::iNew(mesh, selectedCellSet.toc(), ptRegionMax)
        );
    }

    Info<< "\nEnd" << endl;

    return 0;
}


// ************************************************************************* //
