/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | Copyright (C) 1991-2010 OpenCFD Ltd.
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Description
    Selects a cell set through a dictionary.
    
    // nrs
    setFieldsLR is a custom verison of setFields which calculates alpha1 for 
    partially filled cells cut by the undisturbed free surface.  Not written for the 
    general case (e.g. it assumes that normal to the free surface is the Y axis) 
    // srn
    
    // nrs 14/08/2012
    Now modified for the general case, using the gravity vector to determine
    the normal to the free surface
    // srn 14/08/2012

\*---------------------------------------------------------------------------*/
 
#include "argList.H"
#include "timeSelector.H"
#include "Time.H"
#include "fvMesh.H"
#include "topoSetSource.H"
#include "cellSet.H"
#include "faceSet.H"
#include "volFields.H"
#include "boxToCell.H"
#include "plane.H"

#include "cuttingPlane.H"
#include "triPointRef.H"

#include "uniformDimensionedFields.H"

using namespace Foam;

template<class Type>
bool setCellFieldType
(
    const word& fieldTypeDesc,
    const fvMesh& mesh,
    const labelList& selectedCells,
    const point& ptMax,
    Istream& fieldValueStream
)
{
    typedef GeometricField<Type, fvPatchField, volMesh> fieldType;

    if (fieldTypeDesc != fieldType::typeName + "Value")
    {
        return false;
    }

    word fieldName(fieldValueStream);

    IOobject fieldHeader
    (
        fieldName,
        mesh.time().timeName(),
        mesh,
        IOobject::MUST_READ
    );

    bool bShowInfo = false;

    // Check field exists
    if (fieldHeader.headerOk())
    {
        if (bShowInfo)
        	Info<< "    Setting " << fieldHeader.headerClassName()
            << " " << fieldName << endl;

        fieldType field(fieldHeader, mesh);

        const Type& value = pTraits<Type>(fieldValueStream);

        if (bShowInfo)
		Info << " value: " << value << endl;

        if (selectedCells.size() == field.size())
        {
            field.internalField() = value;
        }
        else
        {
            forAll(selectedCells, celli)
            {
                field[selectedCells[celli]] = value;
            }

            // nrs - Set partial alpha based on cell geometry
            uniformDimensionedVectorField g
		(
			IOobject
			(
				"g",
				mesh.time().constant(),
				mesh,
				IOobject::MUST_READ,
				IOobject::NO_WRITE
			)
		);

		// Define cutting plane as undisturbed free surface and find cells that cutting plane intersects
		vector FreeSurface_Normal = (g.value() * -1) / mag(g.value());
		 if (bShowInfo)
			Info << " Vector normal to free surface: " << FreeSurface_Normal << endl;
			
	    double r_freesurface;
	    // Choose free surface height depending on gravity vector, g.  Depends on g being aligned with one axis only,
	    // but the way SetFields works depends on this being the case anyway
	    if (FreeSurface_Normal.x() > 0.5)
		r_freesurface = ptMax.x();
	    else if (FreeSurface_Normal.y() > 0.5)
		r_freesurface = ptMax.y();
	    else
		r_freesurface = ptMax.z();
	    
            if (bShowInfo)
            	Info << " Coordinate of undisturbed free surface: " << r_freesurface << endl;
			
			//const plane myFreeSurfacePlane(ptMax, vector(0, 1, 0)); 
			const plane myFreeSurfacePlane(ptMax, FreeSurface_Normal); 
			cuttingPlane myCuttingPlane(myFreeSurfacePlane, mesh, true);
			const labelList& cutCells = myCuttingPlane.cutCells();
			cellSet someCells(mesh, "someCells", cutCells);
			
			if (bShowInfo)
				Info << " Number of cut cells: " << cutCells.size() << endl;

			//bShowInfo = false;
			
			//const faceList & ff = mesh.faces();
			const pointField & pp = mesh.points();

			// cellSet finds a list of triangular faces so in the list, we will most probably get all our cells listed twice.
			// Store the ID for the last cell we computed and prevent recalculation of the immersed volume;
			int nLastCell = -1;

			forAll(cutCells, celli)
			{
				int nCellID = cutCells[celli];

				if (nCellID != nLastCell)
				{
					nLastCell = nCellID;

					if (nCellID == 4444)
						bShowInfo = true;
					if (bShowInfo)
						Info << endl << endl << " Cell ID: " << nCellID << " Centroid: " << mesh.cellCentres()[nCellID]
											<< " Volume: " << mesh.cellVolumes()[nCellID] << endl << endl << endl;

					const labelList& faces = mesh.cells()[nCellID];
					//const labelListList& pointEdges = mesh.pointEdges();
					// OpenFOAM doesn't seem to support proper lists so we have to stick with
					// lists that have to have their size declared apriori
					const label maxedges = 4;
					edgeList myIntersectingEdges(maxedges); // don't know what max number of sides is
					int nNumIntersectingEdges = 0;

					// find the bottom face (not going to work if bottom face cuts the free surface - Fine for Aquarius
					// as we know that the bottom face will always be horizontal, but won't work for the general case
					face myBottomFace;
					bool bBottomFaceFound = false; // would rather test for myBottomFace == null but it doesn't seem to be supported

					forAll(faces, facei)
					{
						int nFaceID = faces[facei];
						if (bShowInfo)
							Info << " face: " << facei << " ID: " << nFaceID << endl;
						const face& myFace = mesh.faces()[nFaceID];
						if (bShowInfo)
							Info << " face details: " << myFace << endl;
						pointField myFacePoints = myFace.points(pp);

						if (bShowInfo)
							Info << " myFacePoints: " << myFacePoints << endl;

						//double rMax = Foam::max(myFacePoints & vector(0,1,0));
						//double rMin = Foam::min(myFacePoints & vector(0,1,0));
						double rMax = Foam::max(myFacePoints & FreeSurface_Normal);
						double rMin = Foam::min(myFacePoints & FreeSurface_Normal);

						if (rMax < r_freesurface)
						{
							if (bShowInfo)
								Info << " rMax of " << rMax << " is below free surface level of " << r_freesurface << " min is: " << rMin << endl;
							myBottomFace = myFace;
							bBottomFaceFound = true;
						}
						else if (rMin < r_freesurface && rMax > r_freesurface)
						{
							if (bShowInfo)
								Info << " Face cuts surface edge " << endl;
							// face cuts the free surface.  Find the edges that cut the free surface and store them
							const edgeList& myEdges = myFace.edges();
							forAll(myEdges, edgei)
							{
								if (bShowInfo)
									Info << " Start: " << pp[myEdges[edgei].start()] << " End: " << pp[myEdges[edgei].end()] << endl;
								bool bIntersects = false;
								
								if (FreeSurface_Normal.x() > 0.5)
								{
									if ((pp[myEdges[edgei].start()].x() < r_freesurface && pp[myEdges[edgei].end()].x() > r_freesurface) ||
										(pp[myEdges[edgei].start()].x() > r_freesurface && pp[myEdges[edgei].end()].x() < r_freesurface))
										bIntersects = true;
								}
								else if (FreeSurface_Normal.y() > 0.5)
								{
									if ((pp[myEdges[edgei].start()].y() < r_freesurface && pp[myEdges[edgei].end()].y() > r_freesurface) ||
										(pp[myEdges[edgei].start()].y() > r_freesurface && pp[myEdges[edgei].end()].y() < r_freesurface))
										bIntersects = true;
								}
								else
								{
									if ((pp[myEdges[edgei].start()].z() < r_freesurface && pp[myEdges[edgei].end()].z() > r_freesurface) ||
										(pp[myEdges[edgei].start()].z() > r_freesurface && pp[myEdges[edgei].end()].z() < r_freesurface))
										bIntersects = true;
								}
								
								if (bIntersects)
								{
									// check if we already have this edge
									bool bAddEdge = true;
									forAll(myIntersectingEdges, edge2i)
									{
										if (myIntersectingEdges[edge2i] == myEdges[edgei])
											bAddEdge = false;
									}
									if (bAddEdge)
									{
										if (bShowInfo)
											Info << " adding edge " << endl;
										myIntersectingEdges[nNumIntersectingEdges] = myEdges[edgei];
										nNumIntersectingEdges++;
									}

									if (bShowInfo)
										Info << " myIntersectingEdges1: " << myIntersectingEdges << endl;
								}
							}
						}
					}

					if (bBottomFaceFound)
					{
						if (bShowInfo)
							Info << " Bottom face: " << myBottomFace << endl;
						const pointField& myBottomFacePoints = myBottomFace.points(pp);

						myIntersectingEdges.resize(nNumIntersectingEdges);
						if (bShowInfo)
							Info << " Intersecting edges: " << myIntersectingEdges << endl;
						// intersect the edges with the free surface to find the new points
						// need to do this in the right order based on the points on the bottom face
						pointField myPointsAtFreeSurface(myBottomFacePoints.size());

						forAll(myBottomFacePoints, point2i)
						{
							point nPoint = myBottomFacePoints[point2i];
							if (bShowInfo)
								Info << endl << " Point: " << point2i << " : " << nPoint << endl;
							// find the matching edge
							forAll(myIntersectingEdges, edge2i)
							{
								const edge& myEdge = myIntersectingEdges[edge2i];
								point ptStartVertex = mesh.points()[myEdge.start()];
								point ptEndVertex = mesh.points()[myEdge.end()];

								if (bShowInfo)
									Info << " StartVertex: " << ptStartVertex <<
										" End vertex: " << ptEndVertex << endl << endl;
									
								if ((ptStartVertex == nPoint) || (ptEndVertex == nPoint))
								{
									if (bShowInfo)
										Info << " Matched edge " << endl;
									point ptNewPointOnFreeSurface;

									if (FreeSurface_Normal.x() > 0.5)
										ptNewPointOnFreeSurface = ptStartVertex + (ptEndVertex - ptStartVertex) *
											((r_freesurface - ptStartVertex.x()) / (ptEndVertex.x() - ptStartVertex.x()));
									else if (FreeSurface_Normal.y() > 0.5)
										ptNewPointOnFreeSurface = ptStartVertex + (ptEndVertex - ptStartVertex) *
											((r_freesurface - ptStartVertex.y()) / (ptEndVertex.y() - ptStartVertex.y()));
									else
										ptNewPointOnFreeSurface = ptStartVertex + (ptEndVertex - ptStartVertex) *
											((r_freesurface - ptStartVertex.z()) / (ptEndVertex.z() - ptStartVertex.z()));
									
									if (bShowInfo)
										Info << endl << " Made new point on free surface.  StartVertex: " << ptStartVertex <<
											" End vertex: " << ptEndVertex << " New Point: " << ptNewPointOnFreeSurface << endl;
									// Add new point to myPointsAtFreeSurface - can use same indexer as myBottomFacePoints
									myPointsAtFreeSurface[point2i] = ptNewPointOnFreeSurface;
								}
							}
							if (bShowInfo)
								Info << " Finished with Point: " << point2i << " : " << nPoint << endl;
							
						}

						if (bShowInfo)
							Info << " New points found: " << myPointsAtFreeSurface << endl;

						// find volume of cell below free surface
						const pointField& myPointsAtFS(myPointsAtFreeSurface);
						if (bShowInfo)
						{
							Info << " myBottomFacePoints: " << myBottomFacePoints << endl;
							Info << " myPointsAtFS: " << myPointsAtFS << endl;
						}

						//double rVol = myBottomFace.sweptVol(myPointsAtFS, myBottomFacePoints);
						//if (bShowInfo)
						//	Info << " Vol from sweptVol: " << rVol << endl;

						// for some reason this is not working if I call face.sweptVol directly.
						// Have to do it longhand instead

						double sv = 0.0;

						point centreOldPoint = point::zero;
						label nPoints = myBottomFacePoints.size();
						for (register label pI=0; pI<nPoints; pI++)
						{
							centreOldPoint += myBottomFacePoints[pI];
						}
						centreOldPoint /= nPoints;

						point centreNewPoint = point::zero;
						for (register label pINew=0; pINew<nPoints; pINew++)
						{
							centreNewPoint += myPointsAtFS[pINew];
						}
						centreNewPoint /= nPoints;

						point nextOldPoint = centreOldPoint;
						point nextNewPoint = centreNewPoint;

						register label pI2;
						for (pI2 = 0; pI2 < nPoints; pI2++)
						{
							if (pI2 < nPoints - 1)
							{
								nextOldPoint = myBottomFacePoints[pI2 + 1];
								nextNewPoint = myPointsAtFS[pI2 + 1];
							}
							else
							{
								nextOldPoint = myBottomFacePoints[0];
								nextNewPoint = myPointsAtFS[0];
							}

							// Note: for best accuracy, centre point always comes last
							sv += triPointRef
								  (
									  centreOldPoint,
									  myBottomFacePoints[pI2],
									  nextOldPoint
								  ).sweptVol
								  (
									  triPointRef
									  (
										  centreNewPoint,
										  myPointsAtFS[pI2],
										  nextNewPoint
									  )
								  );
						}

						if (bShowInfo)
							Info << " Cell volume: " << mesh.cellVolumes()[nCellID] << " Volume under free surface: " << sv <<
								" Set Alpha1 to: " << fabs(sv) / mesh.cellVolumes()[nCellID] << endl;

						bShowInfo = false;
						// set alpha1 to new value
						// value will invariably have been set to 1 in setFields, but this ensures consistency and gets it in the correct format
						// NRS 30/05/2012
						// Sometimes finds negative of volume dut to the way cell vertices are numbered, so 
						// always use the magnitude of sv
						// field[nCellID] = value * sv / mesh.cellVolumes()[nCellID];
						// ensure alpha1 is between 0 and 1
						double alpha1 = fabs(sv) / mesh.cellVolumes()[nCellID];
						if (alpha1 < 0.0)
							alpha1 = 0.0;
						else if (alpha1 > 1.0)
							alpha1 = 1.0;

						field[nCellID] = value * alpha1; 
						
						// SRN 30/05/2012
					}
					else
					{
						if (bShowInfo)
							Info << " No bottom face found " << endl;
					}
				}
			}
		}

        forAll(field.boundaryField(), patchi)
        {
            field.boundaryField()[patchi] =
                field.boundaryField()[patchi].patchInternalField();
        }

        field.write();
    }
    else
    {
        WarningIn
        (
            "void setFieldType"
            "(const fvMesh& mesh, const labelList& selectedCells,"
            "Istream& fieldValueStream)"
        ) << "Field " << fieldName << " not found" << endl;
    }

    return true;
}


class setCellField
{
public:

    setCellField()
    {}

    autoPtr<setCellField> clone() const
    {
        return autoPtr<setCellField>(new setCellField());
    }

    point ptRegionMax;
    point ptRegionMin;

    class iNew
    {
        const fvMesh& mesh_;
        const labelList& selectedCells_;
        const point& ptMax_;

    public:

        iNew(const fvMesh& mesh, const labelList& selectedCells, const point& ptMax)
        :
            mesh_(mesh),
            selectedCells_(selectedCells),
            ptMax_(ptMax)
        {}

        autoPtr<setCellField> operator()(Istream& fieldValues) const
        {
            word fieldType(fieldValues);

            if
            (
               !(
                    setCellFieldType<scalar>
                        (fieldType, mesh_, selectedCells_, ptMax_, fieldValues)
                 || setCellFieldType<vector>
                        (fieldType, mesh_, selectedCells_, ptMax_, fieldValues)
                 || setCellFieldType<sphericalTensor>
                        (fieldType, mesh_, selectedCells_, ptMax_, fieldValues)
                 || setCellFieldType<symmTensor>
                        (fieldType, mesh_, selectedCells_, ptMax_, fieldValues)
                 || setCellFieldType<tensor>
                        (fieldType, mesh_, selectedCells_, ptMax_, fieldValues)
                )
            )
            {
                WarningIn("setCellField::iNew::operator()(Istream& is)")
                    << "field type " << fieldType << " not currently supported"
                    << endl;
            }

            return autoPtr<setCellField>(new setCellField());
        }
    };
};


template<class Type>
bool setFaceFieldType
(
    const word& fieldTypeDesc,
    const fvMesh& mesh,
    const labelList& selectedFaces,
    Istream& fieldValueStream
)
{
    typedef GeometricField<Type, fvPatchField, volMesh> fieldType;

    if (fieldTypeDesc != fieldType::typeName + "Value")
    {
        return false;
    }

    word fieldName(fieldValueStream);

    IOobject fieldHeader
    (
        fieldName,
        mesh.time().timeName(),
        mesh,
        IOobject::MUST_READ
    );

    // Check field exists
    if (fieldHeader.headerOk())
    {
        Info<< "    Setting patchField values of "
            << fieldHeader.headerClassName()
            << " " << fieldName << endl;

        fieldType field(fieldHeader, mesh);

        const Type& value = pTraits<Type>(fieldValueStream);

        // Create flat list of selected faces and their value.
        Field<Type> allBoundaryValues(mesh.nFaces()-mesh.nInternalFaces());
        forAll(field.boundaryField(), patchi)
        {
            SubField<Type>
            (
                allBoundaryValues,
                field.boundaryField()[patchi].size(),
                field.boundaryField()[patchi].patch().start()
              - mesh.nInternalFaces()
            ).assign(field.boundaryField()[patchi]);
        }

        // Override
        labelList nChanged(field.boundaryField().size(), 0);
        forAll(selectedFaces, i)
        {
            label facei = selectedFaces[i];
            if (mesh.isInternalFace(facei))
            {
                WarningIn("setFaceFieldType(..)")
                    << "Ignoring internal face " << facei << endl;
            }
            else
            {
                label bFaceI = facei-mesh.nInternalFaces();
                allBoundaryValues[bFaceI] = value;
                nChanged[mesh.boundaryMesh().patchID()[bFaceI]]++;
            }
        }

        Pstream::listCombineGather(nChanged, plusEqOp<label>());
        Pstream::listCombineScatter(nChanged);

        // Reassign.
        forAll(field.boundaryField(), patchi)
        {
            if (nChanged[patchi] > 0)
            {
                Info<< "    On patch "
                    << field.boundaryField()[patchi].patch().name()
                    << " set " << nChanged[patchi] << " values" << endl;
                field.boundaryField()[patchi] == SubField<Type>
                (
                    allBoundaryValues,
                    field.boundaryField()[patchi].size(),
                    field.boundaryField()[patchi].patch().start()
                  - mesh.nInternalFaces()
                );
            }
        }

        field.write();
    }
    else
    {
        WarningIn
        (
            "void setFaceFieldType"
            "(const fvMesh& mesh, const labelList& selectedFaces,"
            "Istream& fieldValueStream)"
        ) << "Field " << fieldName << " not found" << endl;
    }

    return true;
}


class setFaceField
{

public:

    setFaceField()
    {}

    autoPtr<setFaceField> clone() const
    {
        return autoPtr<setFaceField>(new setFaceField());
    }

    class iNew
    {
        const fvMesh& mesh_;
        const labelList& selectedFaces_;

    public:

        iNew(const fvMesh& mesh, const labelList& selectedFaces)
        :
            mesh_(mesh),
            selectedFaces_(selectedFaces)
        {}

        autoPtr<setFaceField> operator()(Istream& fieldValues) const
        {
            word fieldType(fieldValues);

            if
            (
               !(
                    setFaceFieldType<scalar>
                        (fieldType, mesh_, selectedFaces_, fieldValues)
                 || setFaceFieldType<vector>
                        (fieldType, mesh_, selectedFaces_, fieldValues)
                 || setFaceFieldType<sphericalTensor>
                        (fieldType, mesh_, selectedFaces_, fieldValues)
                 || setFaceFieldType<symmTensor>
                        (fieldType, mesh_, selectedFaces_, fieldValues)
                 || setFaceFieldType<tensor>
                        (fieldType, mesh_, selectedFaces_, fieldValues)
                )
            )
            {
                WarningIn("setFaceField::iNew::operator()(Istream& is)")
                    << "field type " << fieldType << " not currently supported"
                    << endl;
            }

            return autoPtr<setFaceField>(new setFaceField());
        }
    };
};


// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char *argv[])
{
    #include "addRegionOption.H"
    #include "setRootCase.H"
    #include "createTime.H"
    #include "createNamedMesh.H"

    Info<< "Reading setFieldsDict\n" << endl;

    IOdictionary setFieldsDict
    (
        IOobject
        (
            "setFieldsDict",
            runTime.system(),
            mesh,
            IOobject::MUST_READ_IF_MODIFIED,
            IOobject::NO_WRITE
        )
    );

    if (setFieldsDict.found("defaultFieldValues"))
    {
        Info<< "Setting field default values" << endl;
        PtrList<setCellField> defaultFieldValues
        (
            setFieldsDict.lookup("defaultFieldValues"),
            setCellField::iNew(mesh, labelList(mesh.nCells()), point(0,0,0))
        );
        Info<< endl;
    }


    Info<< "Setting field region values" << endl;

    PtrList<entry> regions(setFieldsDict.lookup("regions"));

    forAll(regions, regionI)
    {
        const entry& region = regions[regionI];

        autoPtr<topoSetSource> source =
            topoSetSource::New(region.keyword(), mesh, region.dict());

        if (source().setType() == topoSetSource::CELLSETSOURCE)
        {
	    cellSet selectedCellSet
            (
                mesh,
                "cellSet",
                mesh.nCells()/10+1  // Reasonable size estimate.
            );

            source->applyToSet
            (
                topoSetSource::NEW,
                selectedCellSet
            );

            // nrs
            point ptRegionMax, ptRegionMin;

            if (regions.size() == 1) // only do this for conventional setFieldsDict
	    {
		const entry& region = regions[0];
		if (region.name() =="::boxToCell")
		{
			//Info << " region end line: " << region.endLineNumber() << endl;
			//Info << " region keyword: " << region.keyword() << endl;
			//Info << " region dict: " << region.dict() << endl;
			//Info << region.dict().lookup("box") << endl;

			treeBoundBox bb;
			bb = region.dict().lookup("box");
			ptRegionMax = bb.max();
			ptRegionMin = bb.min();
		}
	    }

            PtrList<setCellField> fieldValues
            (
                region.dict().lookup("fieldValues"),
                setCellField::iNew(mesh, selectedCellSet.toc(), ptRegionMax)
            );
        }
        else if (source().setType() == topoSetSource::FACESETSOURCE)
        {
            faceSet selectedFaceSet
            (
                mesh,
                "faceSet",
                (mesh.nFaces()-mesh.nInternalFaces())/10+1
            );

            source->applyToSet
            (
                topoSetSource::NEW,
                selectedFaceSet
            );

            PtrList<setFaceField> fieldValues
            (
                region.dict().lookup("fieldValues"),
                setFaceField::iNew(mesh, selectedFaceSet.toc())
            );
        }
    }

    Info<< "\nEnd" << endl;

    return 0;
}


// ************************************************************************* //
